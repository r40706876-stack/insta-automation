"""
Walkman-Chanakya-905 (legacy Hindi font encoding) -> Unicode Devanagari converter.
Built for the science PYQ book text (the PDF's Hindi is stored in this legacy encoding).
"""
import re
from collections import Counter

I_MARK = ""     # chhoti i matra (ि) - encoding me vyanjan se PEHLE aati hai
R_MARK = ""     # reph (र्) - encoding me akshar ke BAAD aata hai
N_MARK = ""     # nukta - encoding me vyanjan se pehle

# "â" wale akshar: k e [matra] â  = क + matra   (h/H e â = फ)
_HOOK_BASE = {"Ø": "फ्र", "k": "क", "h": "फ", "H": "फ", "ø": "फ्र", "Ä": "क्न", "ò": "क्त", "›": "क्र"}
_HOOK_RE = re.compile(r"([khHøÄò›Ø])e([gtsbwWQB=@R]*)â")

MAP = {
    # svar
    "Dee@": "ऑ", "Deef": "अ" + I_MARK, "Deeq": "अ" + I_MARK, "DeeW": "ओं", "DeeX": "ओं" + R_MARK, "DeeR": "आईं", "Deew": "औ", "Dees": "ओ", "Dee": "आ", "De": "अ", "Dew": "औ",
    "F&": "ई", "FË": "ईं", "F": "इ", "G": "उ", "T": "ऊ", "Ss": "ऐ", "S": "ए", "$e+": "ऋ",
    # vyanjan: aadha (X) aur poora (Xe)
    "k": "क्", "ke": "क", "keä": "क्", "K": "ख्", "Ke": "ख", "i": "ग्", "ie": "ग", "I": "घ्", "Ie": "घ",
    "Û": "च्", "Ûe": "च", "Ú": "छ", "p": "ज्", "pe": "ज", "P": "झ्", "Pe": "झ",
    "š": "ट", "\"": "ठ", "[": "ड", "{": "ढ", "C": "ण्", "Ce": "ण",
    "l": "त्", "le": "त", "L": "थ्", "Le": "थ", "o": "द", "O": "ध्", "Oe": "ध", "v": "न्", "ve": "न",
    "h": "प्", "he": "प", "H": "फ्", "Heä": "फ्", "heä": "फ्", "y": "ब्", "ye": "ब", "Y": "भ्", "Ye": "भ",
    "c": "म्", "ce": "म", "Ù": "य्", "Ùe": "य", "j": "र", "u": "ल्", "ue": "ल", "J": "व्", "Je": "व",
    "M": "श्", "Me": "श", "<": "ष्", "<e": "ष", "m": "स्", "me": "स", "n": "ह",
    # sanyukt
    "#": "क्ष्", "#e": "क्ष", "$": "त्र्", "$e": "त्र", "%": "ज्ञ्", "%e": "ज्ञ", "Ø": "प्र्", "Øe": "प्र",
    "«": "ग्र्", "«e": "ग्र", "ß": "श्र्", "ße": "श्र", "Õ": "श्व्", "Õe": "श्व", "œ": "स्र्", "œe": "स्र",
    "Œ": "स्त्र्", "Œe": "स्त्र", "§": "श्च्", "§e": "श्च", "V": "न्न्", "Ve": "न्न", "ë": "श्", "ëe": "श",
    "ø": "फ्र्", "òe": "त्त", "ò": "त्त्", "›": "क्र्", "ÿ": "ह्म्", "ÿe": "ह्म",
    "õ": "द्र", "É": "द्व", "Å": "द्य्", "Åe": "द्य", "æ": "द्ध", "ù": "हृ", "Ü": "हृ", "Â": "दृ", "ó": "ट्ट", "ñ": "ड्ड",
    "ª": "ट्ठ", "ú": "ट्ठ", "‰": "ष्ठ", "°": "ष्ट", "¢": "ह्य्", "¢e": "ह्य", "å": "ह्", "Ö": "ह्न", "ö": "द्द", "£": "ह्व",
    "Æ": "द्भ", "™": "रू", "¤": "रू", "®": "रु",
    "Í": "्र", "Ç": "्र", "^": "्र", "ü": "्र", "Ÿe": "्य", "Ÿ": "्य",
    # matra
    "ef": I_MARK, "eq": I_MARK, "q": I_MARK, "f": I_MARK,
    "er": "ी", "eR": "ीं", "ea": "ी" + R_MARK, "ex": "ो" + R_MARK, "eX": "ों" + R_MARK, "e@": "ॉ",
    "es": "ो", "ew": "ौ", "eW": "ों", "eQ": "ौं", "e": "ा",
    "r": "ी", "R": "ीं", "a": "ी" + R_MARK, "x": "े" + R_MARK, "X": "ें" + R_MARK,
    "g": "ु", "t": "ू", "=": "ृ", "s": "े", "w": "ै", "Q": "ैं", "W": "ें", "b": "ं", "B": "ँ",
    "&": R_MARK, "Ë": "ं" + R_MARK, "@": "ॅ", "Š": "ः", "d": "्", "ä": "्", "Ì": N_MARK,
    "~": "।", "·": "=", "\x02": "-",
}
_MAXK = max(len(k) for k in MAP)

CONS = "\u0915-\u0939\u0958-\u095F"
_CLUSTER = rf"(?:[{CONS}]़?्)*[{CONS}]़?"
_MATRA = "ािीुूृेैोौंँॅः"
_ENC_CHARS = set("[¢æ®Çõ") | set("âÙ~&šØÛäòõÌ^›$#<™ÉÅÚ«{Ç碮%ßùœ§ÂóÕëøŒŸñ‰¤Öö寪Ëü\"")


def _tokenize(s):
    out, i = [], 0
    while i < len(s):
        for L in range(min(_MAXK, len(s) - i), 0, -1):
            ch = s[i:i + L]
            if ch in MAP:
                out.append(MAP[ch])
                i += L
                break
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def convert_word(w):
    """Ek encoded shabd -> Unicode."""
    w = w.replace("]", N_MARK) if re.search(r"\][khHpJjCcmve]", w) else w.replace("]", ".")
    w = _HOOK_RE.sub(lambda m: "" + _HOOK_BASE[m.group(1)] + "" + m.group(2), w)
    # hook se bana poora akshar tokenizer na chhede
    parts = re.split(r"(.*?)", w)
    s = "".join(p if i % 2 else _tokenize(p) for i, p in enumerate(parts))
    # nukta: vyanjan ke baad
    s = re.sub(N_MARK + rf"([{CONS}])", r"\1़", s)
    s = s.replace(N_MARK, "")
    # ि: cluster ke baad
    for _ in range(3):
        s = re.sub(I_MARK + "(" + _CLUSTER + ")", r"\1ि", s)
    s = s.replace(I_MARK, "ि")
    # rakar / ya-phala matra ke baad aaya ho to aage lao
    s = re.sub(rf"([{CONS}])([{_MATRA}]+)(्[रय])", r"\1\3\2", s)
    # reph: syllable ke pehle
    for _ in range(3):
        s = re.sub("(" + _CLUSTER + ")([" + _MATRA + "]*)" + R_MARK, r"र्\1\2", s)
    s = s.replace(R_MARK, "")
    s = (s.replace("ाे", "ो").replace("ाै", "ौ").replace("ाें", "ों").replace("अा", "आ")
         .replace("ाॅ", "ॉ").replace("ंु", "ुं").replace("ंू", "ूं").replace("ंे", "ें").replace("ंी", "ीं"))
    return s


_BAD = re.compile(
    rf"^[{_MATRA}़्]|[अआइईउऊएऐओऔऑ][ािीुूृेैोौ्]|[ािीुूृेैोौ][ािीुूृेैोौ]|्[ािीुूृेैोौंँ]|[A-Za-z-]")


def is_valid_hi(s):
    return bool(s) and not _BAD.search(s) and bool(re.search(r"[ऀ-ॿ]", s))


_ENG_KEEP = re.compile(
    r"^(?:SI|S\.I\.?|pH|DNA|RNA|ATP|ADP|LPG|CNG|AC|DC|EMF|HIV|AIDS|RBC|WBC|RBCs|ICMR|NIV|SONAR|RADAR|LED|LCD|"
    r"kWh|KWh|kW|KW|MW|Hz|kHz|MHz|eV|cm|mm|km|kg|mg|ml|mL|m|s|g|J|N|W|V|A|K|C|Pa|ohm|Ω|"
    r"(?:[A-Z][a-z]?\d*){1,6}\d(?:[A-Z][a-z]?\d*)*|[A-Z][a-z]?\d+[A-Za-z0-9]*|NaCl|NaOH|HCl|KOH|KCl|AgCl|HNO3|"
    r"[A-Za-z]|[a-z]?\d+[a-zA-Z]{1,3}\d?)$")

_ENGLISH_HINT = re.compile(r"^[A-Za-z][a-z'’]+[a-z]$")


ELEMENTS = set("""H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr
Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os
Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu OH TT tt Tt CuO""".split())
_ROMAN = re.compile(r"^(?:i{1,3}|iv|vi{0,3}|ix|x{1,3}i{0,3}|xi?v|I{1,3}|IV|VI{0,3}|IX|X{1,3}I{0,3})$")


def looks_english(tok, in_paren=False, hindi_freq=None):
    """ASCII tok: English hai (waise hi rakho) ya encoded Hindi?"""
    core = tok.strip(".,;:!?'‘’“”()-–/")
    if not core:
        return True
    if any(c in _ENC_CHARS for c in core):
        return False
    if _ROMAN.match(core) or core in ELEMENTS or _ENG_KEEP.match(core):
        return True
    if re.fullmatch(r"[\d.,/×+\-–=%°]+", core):
        return True
    if "-" in core or "/" in core:
        parts = [p for p in re.split(r"[-/]", core) if p]
        if parts and all(looks_english(p, in_paren, hindi_freq) for p in parts):
            return True
    if re.search(r"[a-z][A-Z]", core) and not re.search(r"\d", core) and not re.fullmatch(r"(?:[A-Z][a-z]?)+", core):
        return False
    conv = convert_word(core)
    if not is_valid_hi(conv):
        return True
    if in_paren and hindi_freq is not None and hindi_freq.get(conv, 0) < 2:
        return True
    return False


def hindi_vocab(text):
    """Bracket ke bahar wale shabd (jo convert ho sakte hain) -> Hindi shabdon ki ginti."""
    c = Counter()
    depth = 0
    for tok in re.split(r"[ \t]+|(\n)", text):
        if not tok:
            continue
        if tok == "\n":
            depth = 0
            continue
        if tok.startswith("("):
            depth += 1
        if depth == 0:
            core = tok.strip(".,;:!?'\"‘’“”()[]{}-–/~")
            if core and re.fullmatch(r"[^\s]+", core):
                w = convert_word(core)
                if is_valid_hi(w):
                    c[w] += 1
        if tok.endswith(")"):
            depth = max(0, depth - 1)
    return c


_FRAG_START = set("eswtg=bBWQRrxXa@äd&ËÇ^üŸŠâ")


def join_fragments(text):
    """PDF ne shabd beech me tod diya ho ('Jeeue s' = 'वाल े') to jodo."""
    lines = []
    for line in text.split("\n"):
        out = []
        for tok in line.split(" "):
            if out and tok and out[-1] and tok[0] in _FRAG_START:
                prev = out[-1]
                pc = prev.lstrip("(‘“'")
                tc = tok.rstrip(".,;?!~)'’”")
                alone_bad = len(tc) == 1 or not is_valid_hi(convert_word(tc))
                if (pc and not pc[-1] in ".,;?!~)'’”:" and alone_bad and not looks_english(pc)
                        and is_valid_hi(convert_word(pc + tc))):
                    out[-1] = prev + tok
                    continue
            out.append(tok)
        lines.append(" ".join(out))
    return "\n".join(lines)


def _convert_body(body, in_paren, hindi_freq):
    # ank + shabd (12JeW = 12वें)
    m = re.match(r"^(\d+(?:\.\d+)?)(.+)$", body)
    if m:
        rest = m.group(2)
        if looks_english(rest, in_paren, hindi_freq) and not re.search(r"[–\-]", rest):
            return body
        return m.group(1) + _convert_body(rest, in_paren, hindi_freq)
    # dash se jude alag-alag hisse (जैसे–NaHCO3)
    if re.search(r"[–\-]", body) and len(body) > 3:
        parts = re.split(r"([–\-]+)", body)
        if len(parts) > 1:
            return "".join(p if (i % 2 or not p or looks_english(p, in_paren, hindi_freq))
                           else _convert_body(p, in_paren, hindi_freq) for i, p in enumerate(parts))
    if looks_english(body, in_paren, hindi_freq):
        return body
    b, vis = body, ""
    if b.endswith(":") and len(b) > 1:
        b, vis = b[:-1], "ः"
    return convert_word(b) + vis


def convert_text(text, hindi_freq=None):
    """Poora text (Hindi encoded + beech me English) -> Unicode."""
    out = []
    text = join_fragments(text)
    pieces = re.split(r"(\s+)", text)
    # bracket ke andar ka ASCII hissa: zyada-tar English ho to poora English
    depth = 0
    for tok in pieces:
        if not tok or tok.isspace():
            if tok and "\n" in tok:
                depth = 0
            out.append(tok)
            continue
        opens = tok.count("(")
        depth += opens
        in_paren = depth > 0
        depth -= tok.count(")")
        depth = max(depth, 0)
        lead = tok[:len(tok) - len(tok.lstrip("(‘“'"))]
        rest = tok[len(lead):]
        body = rest.rstrip("),.;?!~'’”")
        trail = rest[len(body):]
        if not body:
            out.append(tok.replace("~", "।"))
            continue
        special = bool(re.search(r"[A-Za-z\x80-\uFFFF][–\-]|[–\-][A-Za-z\x80-\uFFFF]", body)
                       or re.match(r"^\d+(?:\.\d+)?[A-Za-z\x80-\uFFFF]", body))
        if not special and looks_english(body, in_paren, hindi_freq):
            out.append(lead + body + trail.replace("~", "।"))
            continue
        out.append(lead + _convert_body(body, in_paren, hindi_freq) + trail.replace("~", "।"))
    return "".join(out).replace("\x02", "-").replace(" · ", " = ").replace("·", "=")


if __name__ == "__main__":
    tests = ["kesâ", "keâer", "ùoÙe keâer ceebmehesefMeÙeeb ueÙeyeæ ™he mes mebkegâefÛele Deewj",
             "efJe%eeve", "Tpee&", "keâeyeexvesš", "DeeJeleea", "efveefce&le", "Fueskeäš^e@ve", "yeÌ{lee",
             "kewâequmeÙece", "efÛeÖ", "Øeef›eâÙee", "veneR", "nQ~", "hetCeeËkeâ", "FËOeveeW", "OegÇJeeW",
             "]heâejsveneFš", "iuetkeâes]pe", "Âef°", "Meefòeâ", "keâòe&JÙe", "›eâceMeŠ", "Dele:", "$e+Ceelcekeâ",
             "šŸetye", "nefñÙeeW", "Fkeâªe", "yeÇÿeeb[", "ojx", "heoeLeeX", "Je<eex", "ieg®lJeekeâ<e&Ce",
             "DeLee&led", "ØeeflejesOekeâlee keâer SI FkeâeF& Deesce-ceeršj (ohm-m) nw~", "(Magnification)",
             "ueWme keâer #ecelee keâe SI cee$ekeâ keäÙee nw?", "Heäuesefcebie", "ëe=bKeuee", "efceóer"]
    for t in tests:
        print(t, "->", convert_text(t, Counter()))
