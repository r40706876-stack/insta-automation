"""
Science PYQ book (legacy-font PDF text) -> clean Unicode question bank (science_pyq_bank.json).

Ek baar chalta hai (offline). Reel script (auto_poster.py) sirf JSON padhti hai.
Usage: python build_bank.py <book_text.txt> [out.json]
"""
import re
import sys
import json
import hashlib
from collections import Counter, defaultdict

import chanakya as C

SUBJECTS = [("Physics", "भौतिक विज्ञान"), ("Chemistry", "रसायन विज्ञान"), ("Biology", "जीव विज्ञान")]

NOISE = re.compile(r"Join @yct_hub.*|^\s*YCT\s*\d*\s*$|^\s*\d{1,3}\s*$|^\s*Yeeie-\d\s*$")
Q_START = re.compile(r"^\s*(\d{1,4})\s*\.\s*(.*)$")
OPT = re.compile(r"\(([a-d])\)")
EXAM = re.compile(r"RRB|Group\s*-?\s*D|NTPC|ALP|SSC|Shift", re.I)
ANS = re.compile(r"^\s*Ans\.?\s*[:\-]?\s*\(?\s*([a-dA-D])\s*\)?\s*[:\-]?\s*(.*)$")
YEAR = re.compile(r"(20\d\d|19\d\d)")


def science_lines(raw):
    lines = raw.split("\n")
    # "Yeeie-1" (भाग-1) ke baad: Physics / Chemistry / Biology; "Yeeie-2" (Computer) pe band
    starts = [i for i, l in enumerate(lines) if l.strip() == "Yeeie-1"]
    end = next(i for i, l in enumerate(lines) if l.strip() == "Yeeie-2")
    # pehla "Yeeie-1" TOC me hai (jahan aage ':' hai) - asli section wale akele hain
    starts = [i for i in starts if i < end][-3:]
    out = []
    for k, st in enumerate(starts):
        en = starts[k + 1] if k + 1 < len(starts) else end
        for l in lines[st + 1:en]:
            if not NOISE.search(l):
                out.append((k, l.rstrip()))
    return out


def _en_key(s):
    return re.sub(r"[^a-z]", "", (s or "").lower())


def toc_names(raw):
    """Vishay-soochi (TOC) ke English naam - asli chapter/topic heading pehchaanne ke liye."""
    lines = raw.split("\n")
    end = next(i for i, l in enumerate(lines) if "keâchÙetšj (Computer)" in l)
    names = set()
    for l in lines[:end]:
        for m in re.findall(r"\(([A-Za-z][^()]{2,80})\)", l):
            k = _en_key(m)
            if len(k) >= 3:
                names.add(k)
    return names


def _valid_heading(h, names):
    m = re.findall(r"\(([A-Za-z][^()]*)\)?", h)
    if not m:
        return False
    k = _en_key(m[-1])
    return len(k) >= 3 and any(k == n or (len(k) >= 8 and (n.startswith(k) or k.startswith(n))) for n in names)


def parse(raw):
    names = toc_names(raw)
    lines = science_lines(raw)
    hf = C.hindi_vocab(C.join_fragments("\n".join(l for _, l in lines)))
    conv = lambda s: " ".join(C.convert_text(s, hf).split())

    qs = []
    chapter, sub = "", ""
    cur = None
    pending_heading = None

    def flush():
        nonlocal cur
        if cur and cur.get("ans") and len(cur.get("opts_raw", "")) > 0:
            qs.append(cur)
        cur = None

    i = 0
    while i < len(lines):
        subj, l = lines[i]
        s = l.strip()
        m = Q_START.match(s)
        if m and (cur is None or cur.get("ans") or "opts_raw" not in cur):
            # naya numbered line: sawal ya chapter heading
            if cur and "opts_raw" not in cur and not cur.get("ans"):
                # pichhla numbered line heading tha (asli heading me English naam bracket me hota hai)
                h = conv(cur["q_raw"])
                if _valid_heading(h, names) and len(h.split()) <= 16 and "?" not in h:
                    chapter, sub = h, ""
            flush()
            cur = {"subject": subj, "num": int(m.group(1)), "q_raw": m.group(2), "chapter": chapter, "sub": sub}
            i += 1
            continue
        if cur is None:
            # sub-heading jaise "(i) cee$ekeâ (Unit)"
            mh = re.match(r"^\(([ivx]+)\)\s*(.+)$", s)
            if mh and _valid_heading(conv(mh.group(2)), names):
                sub = conv(mh.group(2))
            i += 1
            continue
        if cur.get("ans"):
            # vyakhya - agla sawal / heading aane tak
            mh = re.match(r"^\(([ivx]+)\)\s*(.+)$", s)
            if mh and not OPT.search(s) and len(s) < 80 and _valid_heading(conv(mh.group(2)), names):
                sub = conv(mh.group(2))
                flush()
            else:
                cur["exp_raw"] = cur.get("exp_raw", "") + "\n" + l
            i += 1
            continue
        a = ANS.match(s)
        if a:
            cur["ans"] = a.group(1).lower()
            cur["exp_raw"] = a.group(2)
            i += 1
            continue
        if EXAM.search(s) and re.search(r"\d", s) and "opts_raw" in cur:
            cur.setdefault("exams", []).append(" ".join(s.split()))
            i += 1
            continue
        if OPT.search(s) or "opts_raw" in cur:
            if "opts_raw" not in cur:
                k = s.find("(a)")
                if k > 0:
                    cur["q_raw"] += " " + s[:k]
                    s = s[k:]
                cur["opts_raw"] = s
            else:
                cur["opts_raw"] += " " + s
            i += 1
            continue
        mh = re.match(r"^\(([ivx]+)\)\s*(.+)$", s)
        if mh and len(s) < 80 and "?" not in s:
            # heading ke neeche sub-heading: pichhla numbered = chapter
            h = conv(cur["q_raw"])
            if _valid_heading(h, names) and len(h.split()) <= 16 and "?" not in h:
                chapter = h if _valid_heading(h, names) else chapter
            sub = conv(mh.group(2)) if _valid_heading(conv(mh.group(2)), names) else sub
            cur = None
            i += 1
            continue
        cur["q_raw"] += " " + s
        i += 1
    flush()

    out = []
    for q in qs:
        parts = OPT.split(q["opts_raw"])
        opts = {}
        for k in range(1, len(parts) - 1, 2):
            opts[parts[k]] = parts[k + 1]
        if set(opts) != set("abcd"):
            continue
        question = conv(q["q_raw"])
        options = {k: conv(v).strip(" ,;") for k, v in opts.items()}
        exp = conv(q.get("exp_raw", ""))
        out.append({
            "subject": SUBJECTS[q["subject"]][0],
            "subject_hi": SUBJECTS[q["subject"]][1],
            "chapter": q["chapter"],
            "sub": q["sub"],
            "question": question,
            "options": options,
            "answer": q["ans"],
            "exams": q.get("exams", []),
            "explanation": exp[:900],
        })
    return out


# ---------------- quality filter + analysis ----------------

_SKIP_WORDS = ("चित्र", "आरेख", "ग्राफ", "दिए गए चित्र", "सुमेलित", "सूची-I", "सूची-1", "सूची I", "कूट", "निम्न चित्र",
               "स्तम्भ", "कॉलम", "Column", "List")
_GARBAGE = re.compile(r"[-]|[ािीुूृेैोौ]{2}|्[ािीुूृेैोौं]|^[ािीुूृेैोौं्]")


def _latin_ratio(s):
    lat = len(re.findall(r"[A-Za-z]", s))
    hi = len(re.findall(r"[ऀ-ॿ]", s))
    return lat / max(1, lat + hi)


def quality(q):
    """(ok, kaaran) - reel ke layak sawal?"""
    qt, opts = q["question"], q["options"]
    if any(w in qt for w in _SKIP_WORDS):
        return False, "picture/match type"
    if len(qt.split()) > 34:
        return False, "sawal bahut lamba"
    if len(qt) < 12:
        return False, "sawal adhoora"
    for v in opts.values():
        if not v or len(v.split()) > 9 or len(v) > 60:
            return False, "option lamba/khaali"
    texts = [qt] + list(opts.values())
    for t in texts:
        for w in t.split():
            core = w.strip(".,;:?!()‘’'\"।-–")
            if core and _GARBAGE.search(core):
                return False, "conversion garbage"
            # Hindi + Latin ek hi shabd me = galat conversion
            if re.search(r"[ऀ-ॿ]", core) and re.search(r"[A-Za-z]", core):
                return False, "mixed token"
    if _latin_ratio(qt) > 0.45:
        return False, "zyada English/formula"
    if len(set(v.strip() for v in opts.values())) < 4:
        return False, "option dohraav"
    if re.search(r"[=×/+]\s*$|\b[a-z]\s*=\s*$", qt):
        return False, "formula"
    return True, ""


def norm_key(q):
    s = re.sub(r"[^ऀ-ॿA-Za-z0-9]", "", q["question"])
    o = re.sub(r"[^ऀ-ॿA-Za-z0-9]", "", q["options"][q["answer"]])
    return s + "|" + o


def exam_label(tag):
    t = " ".join(tag.split())
    y = YEAR.search(t)
    return ("RRB Group D " + y.group(1)) if y else "RRB Group D"


def build(raw_path, out_path):
    raw = open(raw_path, encoding="utf-8").read()
    items = parse(raw)
    print("parsed:", len(items))
    reasons = Counter()
    good = []
    for q in items:
        ok, why = quality(q)
        if not ok:
            reasons[why] += 1
            continue
        good.append(q)
    print("quality pass:", len(good), dict(reasons))

    # dohraav (same sawal alag shift me) -> ek, exam tags jodo
    merged = {}
    for q in good:
        k = norm_key(q)
        if k in merged:
            merged[k]["exams"] += q["exams"]
        else:
            merged[k] = q
    bank = list(merged.values())
    for q in bank:
        q["exams"] = sorted(set(q["exams"]))
        q["times_asked"] = max(1, len(q["exams"]))
        q["years"] = sorted(set(YEAR.search(e).group(1) for e in q["exams"] if YEAR.search(e)))
        q["id"] = hashlib.md5(norm_key(q).encode()).hexdigest()[:10]
    print("unique:", len(bank))

    # ORDER (analysis): sabse zyada baar poochhe gaye pehle; subject baari-baari (Physics, Chemistry, Biology)
    by_subj = defaultdict(list)
    for q in bank:
        by_subj[q["subject"]].append(q)
    for k in by_subj:
        by_subj[k].sort(key=lambda q: (-q["times_asked"], q["chapter"], q["question"]))
    order = []
    names = [s for s, _ in SUBJECTS]
    while any(by_subj[n] for n in names):
        for n in names:
            if by_subj[n]:
                order.append(by_subj[n].pop(0))
    for i, q in enumerate(order):
        q["seq"] = i + 1

    stats = {
        "total_questions": len(order),
        "by_subject": dict(Counter(q["subject"] for q in order)),
        "asked_2plus": sum(1 for q in order if q["times_asked"] >= 2),
        "asked_3plus": sum(1 for q in order if q["times_asked"] >= 3),
        "top_chapters": Counter(q["chapter"] for q in order).most_common(25),
    }
    json.dump({"version": 1, "stats": stats, "questions": order}, open(out_path, "w", encoding="utf-8"),
              ensure_ascii=False, indent=1)
    print(json.dumps(stats, ensure_ascii=False, indent=1))


if __name__ == "__main__":
    build(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "science_pyq_bank.json")
